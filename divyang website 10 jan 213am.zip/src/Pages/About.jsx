import EligibilityCheck from "./EligibilityCheck";
import MyScheme from "./MyScheme";
import OurVision from "./OurVision";

const About=()=>{
    return(
        <>
    <OurVision/>
    <MyScheme/>
    <EligibilityCheck/>
        </>
    )
    }
    export default About;