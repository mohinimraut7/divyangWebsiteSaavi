import ImageCarousel from "../Components/ImageCarousel";
import SchemesTabs from "./SchemesTabs";
import Services from "./Services";
// import 'bootstrap/dist/css/bootstrap.min.css';

const Home=()=>{
    return(
        <>

<ImageCarousel/>

{/* <SchemesTabs/> */}
<Services/>


        </>
    )
}
export default Home;