const castedropdowndata = [
    { "name": 'ST' },
    { "name": 'SC' },
    { "name": 'OBC' },
    { "name": 'Open' },
    { "name": 'Other' },
    ];

export default castedropdowndata;
