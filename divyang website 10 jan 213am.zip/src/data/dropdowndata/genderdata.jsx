const genderdata = [
    { "gname": 'Male' },
    { "gname": 'Female' },
    { "gname": 'Other' },
    ];

export default genderdata;
