const marriedstatusdata = [
    { "name": 'Unmarried' },
    { "name": 'Married' },
    { "name": 'Divorced' },
    { "name": 'Widowed' },
    { "name": 'Separated' },
    ];

export default marriedstatusdata;
