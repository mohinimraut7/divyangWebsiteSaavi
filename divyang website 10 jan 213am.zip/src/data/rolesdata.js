const rolesdata = [
       {"rolename":"user"},
    // {"rolename":"None"}
    ];

export default rolesdata;
